drop table class_4_ex_5.BelongsTo;

GO
;

drop table class_4_ex_5.Student;

GO
;

drop table class_4_ex_5.Institution;

GO
;

drop table class_4_ex_5.NotStudent;

GO
;

drop table class_4_ex_5.WrittenBy;

GO
;

drop table class_4_ex_5.Author;

GO
;

drop table class_4_ex_5.AttendedBy;

GO
;

drop table class_4_ex_5.HostsPresentation;

GO
;

drop table class_4_ex_5.Attender;

GO
;

drop table class_4_ex_5.Person;

GO
;

drop table class_4_ex_5.Paper;

GO
;

drop table class_4_ex_5.Conference;

GO
;

drop schema class_4_ex_5;

GO
;