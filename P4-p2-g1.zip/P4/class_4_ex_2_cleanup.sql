drop table class_4_ex_2.CanLand
GO
;

drop table class_4_ex_2.Fare
GO
;

drop table class_4_ex_2.Seat
GO
;

drop table class_4_ex_2.LegInstance
GO
;

drop table class_4_ex_2.FlightLeg
GO
;

drop table class_4_ex_2.Flight
GO
;

drop table class_4_ex_2.Airplane
GO
;

drop table class_4_ex_2.Airport
GO
;

drop table class_4_ex_2.AirplaneType
GO
;

drop schema class_4_ex_2
GO
;