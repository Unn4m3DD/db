drop table class_4_ex_6.OptIn;
GO
;
drop table class_4_ex_6.Offers;
GO
;
drop table class_4_ex_6.Activity;
GO
;
drop table class_4_ex_6.Authorized;
GO
;
drop table class_4_ex_6.Student;
GO
;
drop table class_4_ex_6.Class;
GO
;
drop table class_4_ex_6.SponsorEducation;
GO
;
drop table class_4_ex_6.Professor;
GO
;
drop table class_4_ex_6.Person;
GO
;
drop schema class_4_ex_6;
GO
;