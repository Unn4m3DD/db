drop table class_4_ex_4.SellsTo
GO
;

drop table class_4_ex_4.SoldBy
GO
;

drop table class_4_ex_4.[Contains]
GO
;

drop table class_4_ex_4.Perscription
GO
;

drop table class_4_ex_4.Doctor
GO
;

drop table class_4_ex_4.Pharmacy
GO
;

drop table class_4_ex_4.Patient
GO
;

drop table class_4_ex_4.ProducedBy
GO
;

drop table class_4_ex_4.DrugCompany
GO
;

drop table class_4_ex_4.Drug
GO
;

drop schema class_4_ex_4
GO
;