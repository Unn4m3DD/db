GO
;

drop table class_4_ex_1.HeavyVehicle;

GO
;

drop table class_4_ex_1.LightVehicle;

GO
;

drop table class_4_ex_1.Similarity;

GO
;

drop table class_4_ex_1.Rental;

GO
;

drop table class_4_ex_1.Vehicle;

GO
;

drop table class_4_ex_1.VehicleType;

GO
;

drop table class_4_ex_1.Counter;

GO
;

drop table class_4_ex_1.Client;

GO
;

drop schema class_4_ex_1;