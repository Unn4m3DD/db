drop table class_4_ex_3.[Contains];

GO
;

drop table class_4_ex_3.Product;

GO
;

drop table class_4_ex_3.Registred;

GO
;

drop table class_4_ex_3.[Order];

GO
;

drop table class_4_ex_3.Supplier;

GO
;

drop table class_4_ex_3.Warehouse;

GO
;

drop schema class_4_ex_3;

GO
;