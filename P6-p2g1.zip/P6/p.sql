
declare @per_publisher_revenue table(title_id varchar(10), publisher_revenue real);
insert into @per_publisher_revenue 
select
	titles.title_id ,
  avg(ytd_sales * price) - avg(ytd_sales * royalty * price *.01) as publisher_revenue
from
  authors
  inner join titleauthor on authors.au_id = titleauthor.au_id
  inner join titles on titles.title_id = titleauthor.title_id
group by
  titles.title_id,
  titles.title;

select
  titles.title,
  authors.au_fname + ' ' + authors.au_lname as author_name,
  avg(ytd_sales),
  avg(ytd_sales * price) as total_revenue,
  avg(ytd_sales * royalty * royaltyper * price * .01) as authors_revenue,
  publisher_revenue
from
  authors
  inner join titleauthor on authors.au_id = titleauthor.au_id
  inner join titles on titles.title_id = titleauthor.title_id
  inner join @per_publisher_revenue as ppr on ppr.title_id = titles.title_id
group by
  titles.title_id,
  titles.title, 
  authors.au_id,
  authors.au_fname,
  authors.au_lname,
  ppr.publisher_revenue

order by titles.title;
