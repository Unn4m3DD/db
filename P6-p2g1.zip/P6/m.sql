select
  titles.title,
  titles.[type],
  avg_type_advance * 1.5 as avg_advance_times_1_dot_5,
  advance
from
  titles
  inner join (
    select
      titles.[type],
      avg(titles.advance) as avg_type_advance
    from
      titles
    group by
      titles.[type]
  ) as avgs on titles.[type] = avgs.[type]
where
  advance > avg_type_advance * 1.5