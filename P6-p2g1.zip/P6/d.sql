select
  au_fname as first_name,
  au_lname as last_name,
  phone as telephone
from
  dbo.authors
order by
  au_fname,
  au_lname;