select
  titles.title
from
  stores
  inner join sales on sales.stor_id = stores.stor_id
  inner join titles on titles.title_id = sales.title_id
where
  stores.stor_name = 'Bookbeat'