select
  tt.title
from
  titles as tt
except
select
  tt.title
from
  stores as st
  inner join sales as sl on st.stor_id = sl.stor_id
  inner join titles as tt on tt.title_id = sl.title_id
where
  st.stor_name = 'Bookbeat';
