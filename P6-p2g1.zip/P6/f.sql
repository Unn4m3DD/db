select
  pub_id,
  pub_name
from
  publishers
where
  pub_name like '%Bo%';